package cikal.dicoding.submission2.data.source.local.entity

data class MovieEntity (
    var movieId: String,
    var movieTitle: String,
    var moviePoster: String,
    var movieYear: String,
    var movieDesc: String
)