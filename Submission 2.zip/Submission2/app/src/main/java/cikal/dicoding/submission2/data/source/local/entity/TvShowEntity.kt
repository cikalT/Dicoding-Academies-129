package cikal.dicoding.submission2.data.source.local.entity

data class TvShowEntity (
    var tvShowId: String,
    var tvShowTitle: String,
    var tvShowPoster: String,
    var tvShowYear: String,
    var tvShowDesc: String
)